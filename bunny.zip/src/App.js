import './App.css';

import ComponentTwo from './components/hoc/ComponentTwo';
import ComponentOne from './components/hoc/ComponentOne';

function App() {
  return (
    <div className="App">
      
      <ComponentOne />
      <ComponentTwo />

    </div>
  );
}

export default App;
